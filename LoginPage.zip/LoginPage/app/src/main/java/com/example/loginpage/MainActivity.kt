package com.example.loginpage

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.loginpage.MainActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun OnSubmit(view: View?) {
        val editText = findViewById<EditText>(R.id.etUserName)
        val editText1 = findViewById<EditText>(R.id.etPassword)
        if (editText.text.toString() == "Srinitha" && editText1.text.toString() == "1231231234") {
            Toast.makeText(this, "go to Welcome page on click back", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, HomeActivity::class.java)
            val message = editText.text.toString() + " Welcome to the login page "
            intent.putExtra( MSG, message)
            startActivity(intent)
        } else {
            Toast.makeText(this, "Invalid Username or password", Toast.LENGTH_SHORT).show()
            val intent2 = Intent(this, MainActivity::class.java)
            startActivity(intent2)
        }
    }

    companion object {
        const val MSG = "com.example.loginpage.HomeActivity"
    }
}